// Device-owned level compaction and canonical CSR. Counts and size selection
// stay on GPU; no scalar result is needed by the submitting CPU thread.
#pragma once
#include "StressHierarchyKernels.cuh"
namespace Nv { namespace Blast { namespace StressHierarchy {
struct PackingBuffers {
    unsigned *nodeFlags,*nodeMap,*bondFlags,*bondMap,*identity,*component,*bondIdentity,*begin,*refs,*counts;
    std::uint64_t *keys,*sorted;
    CoarseBond* bonds;
};
__device__ __forceinline__ unsigned packingBucket(unsigned n){return n<=1?0:32-__clz(n-1);}
__global__ void beginPacking(Input input,const Status* parent,Status* output,
                             cudaGraphConditionalHandle nodes,cudaGraphConditionalHandle bonds,
                             cudaGraphConditionalHandle rows){
    unsigned nodeCase=Invalid,bondCase=Invalid;
    if(!input.accept || *input.accept){
        if(!parent->initialized || parent->error || !sourceCountsValid(input) || parent->generation!=*input.generation)
            output->error=32;
        else if(output->initialized && parent->generation<output->generation)output->error=4;
        else if(!output->initialized || output->generation!=parent->generation || output->error){
            input=resolvedInput(input);output->error=0;
            nodeCase=packingBucket(input.nodes);bondCase=packingBucket(input.bonds);
        }
    }
    cudaGraphSetConditional(nodes,nodeCase);cudaGraphSetConditional(bonds,bondCase);cudaGraphSetConditional(rows,nodeCase);
}
__global__ void flagPackingNodes(Input input,Buffers parent,PackingBuffers b,unsigned bucket){
    input=resolvedInput(input);const unsigned i=blockIdx.x*blockDim.x+threadIdx.x;
    if(i<=bucket){b.nodeFlags[i]=i<input.nodes && parent.leader[i]==i;b.begin[i]=0;}
}
__global__ void packNodes(Input input,PackingBuffers b,unsigned bucket){
    input=resolvedInput(input);const unsigned i=blockIdx.x*blockDim.x+threadIdx.x;
    if(i<input.nodes && b.nodeFlags[i]){
        const unsigned next=b.nodeMap[i];b.identity[next]=input.identity?input.identity[i]:i;
        b.component[next]=input.component[i];
    }
    if(!i)b.counts[0]=b.nodeMap[bucket];
}
__global__ void flagPackingBonds(Input input,Buffers parent,PackingBuffers b,unsigned bucket){
    input=resolvedInput(input);const unsigned i=blockIdx.x*blockDim.x+threadIdx.x;
    if(i>bucket)return;unsigned live=0;
    if(i<input.bonds){
        const auto e=parent.coarse[i];live=e.scale>0 && (e.a!=Invalid || e.b!=Invalid);
        // Delete only identically zero coarse columns. Rounded nonzero moment
        // terms survive even when both endpoints have the same owner.
        if(e.a==e.b && e.offset0.x==e.offset1.x && e.offset0.y==e.offset1.y && e.offset0.z==e.offset1.z)live=0;
    }
    b.bondFlags[i]=live;
}
__global__ void packBonds(Input input,Buffers parent,PackingBuffers b,unsigned bucket){
    input=resolvedInput(input);const unsigned i=blockIdx.x*blockDim.x+threadIdx.x;
    if(i>=bucket)return;std::uint64_t first=~std::uint64_t(0),second=first;
    if(i<input.bonds && b.bondFlags[i]){
        const unsigned next=b.bondMap[i];auto edge=parent.coarse[i];
        if(edge.a!=Invalid){edge.a=b.nodeMap[edge.a];first=(std::uint64_t(edge.a)<<32)|(next*2);}
        if(edge.b!=Invalid){edge.b=b.nodeMap[edge.b];second=(std::uint64_t(edge.b)<<32)|(next*2+1);}
        b.bonds[next]=edge;b.bondIdentity[next]=input.bondIdentity?input.bondIdentity[i]:i;
    }
    b.keys[2*i]=first;b.keys[2*i+1]=second;if(!i)b.counts[1]=b.bondMap[bucket];
}
__global__ void unpackAdjacency(PackingBuffers b,unsigned entries){
    const unsigned i=blockIdx.x*blockDim.x+threadIdx.x;if(i>=entries)return;
    const std::uint64_t key=b.sorted[i];const unsigned node=unsigned(key>>32),ref=unsigned(key);
    b.refs[i]=node==Invalid?Invalid:(ref>>1)|((ref&1u)<<31);
    if(node!=Invalid && (i+1==entries || unsigned(b.sorted[i+1]>>32)!=node))b.begin[node+1]=i+1;
}
__global__ void commitPacking(const Status* parent,Status* status,PackingBuffers b){
    status->generation=parent->generation;status->initialized=1;++status->builds;status->aggregates=b.counts[0];
}
}}}
