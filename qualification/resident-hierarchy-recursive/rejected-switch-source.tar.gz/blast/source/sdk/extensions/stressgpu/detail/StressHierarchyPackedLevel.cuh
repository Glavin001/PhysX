// Persistent workspace and graph construction for one compact recursive level.
#pragma once
#include "StressHierarchyGraph.cuh"
#include "StressHierarchyPacking.cuh"
#include <cub/device/device_scan.cuh>
#include <cub/device/device_radix_sort.cuh>
namespace Nv { namespace Blast { namespace StressHierarchy {
class PackedLevel {
    Input mInput;Buffers mParent;const Status* mParentStatus;cudaStream_t mStream;
    PackingBuffers mBuffers{};Status* mStatus=nullptr;
    void* mScratch=nullptr;size_t mScratchBytes=0;
    unsigned mNodeBucket=1,mBondBucket=1;bool mAppended=false;
    static void check(cudaError_t e){if(e!=cudaSuccess)throw std::runtime_error(std::string("Resident packed level: ")+cudaGetErrorString(e));}
    template<class T>static void allocate(T*& p,size_t n){check(cudaMalloc(&p,std::max(size_t(1),n)*sizeof(T)));}
    static unsigned rounded(unsigned n){unsigned result=1;while(result<n)result*=2;return result;}
    static unsigned cases(unsigned n){unsigned count=1;while(n>1){n/=2;++count;}return count;}
    void release()noexcept{
        cudaFree(mBuffers.nodeFlags);cudaFree(mBuffers.nodeMap);cudaFree(mBuffers.bondFlags);cudaFree(mBuffers.bondMap);
        cudaFree(mBuffers.identity);cudaFree(mBuffers.component);cudaFree(mBuffers.bondIdentity);
        cudaFree(mBuffers.begin);cudaFree(mBuffers.refs);cudaFree(mBuffers.counts);
        cudaFree(mBuffers.keys);cudaFree(mBuffers.sorted);cudaFree(mBuffers.bonds);cudaFree(mStatus);cudaFree(mScratch);
    }
    void capture(cudaGraph_t body,unsigned phase,unsigned bucket,cudaStream_t stream){
        const unsigned blocks=(bucket+1+Threads-1)/Threads,edgeBlocks=(2*bucket+Threads-1)/Threads;
        size_t bytes=mScratchBytes;
        check(cudaStreamBeginCaptureToGraph(stream,body,nullptr,nullptr,0,cudaStreamCaptureModeThreadLocal));
        if(phase==0){
            flagPackingNodes<<<blocks,Threads,0,stream>>>(mInput,mParent,mBuffers,bucket);
            check(cub::DeviceScan::ExclusiveSum(mScratch,bytes,mBuffers.nodeFlags,mBuffers.nodeMap,bucket+1,stream));
            packNodes<<<blocks,Threads,0,stream>>>(mInput,mBuffers,bucket);
        } else if(phase==1){
            flagPackingBonds<<<blocks,Threads,0,stream>>>(mInput,mParent,mBuffers,bucket);
            check(cub::DeviceScan::ExclusiveSum(mScratch,bytes,mBuffers.bondFlags,mBuffers.bondMap,bucket+1,stream));
            packBonds<<<blocks,Threads,0,stream>>>(mInput,mParent,mBuffers,bucket);
            bytes=mScratchBytes;
            check(cub::DeviceRadixSort::SortKeys(mScratch,bytes,mBuffers.keys,mBuffers.sorted,2*bucket,0,64,stream));
            unpackAdjacency<<<edgeBlocks,Threads,0,stream>>>(mBuffers,2*bucket);
        } else {
            check(cub::DeviceScan::InclusiveScan(mScratch,bytes,mBuffers.begin,mBuffers.begin,cub::Max(),bucket+1,stream));
            commitPacking<<<1,1,0,stream>>>(mParentStatus,mStatus,mBuffers);
        }
        check(cudaGetLastError());cudaGraph_t result=nullptr;check(cudaStreamEndCapture(stream,&result));
    }
public:
    PackedLevel(Input input,const Graph& parent,cudaStream_t stream):mInput(input),mParent(parent.buffers()),mParentStatus(parent.status()),mStream(stream){
        if(input.nodes>(1u<<29) || input.bonds>(1u<<29))throw std::runtime_error("Resident packed level exceeds scan index capacity");
        mNodeBucket=rounded(input.nodes);mBondBucket=rounded(input.bonds);
        try {
            allocate(mBuffers.nodeFlags,mNodeBucket+1);allocate(mBuffers.nodeMap,mNodeBucket+1);
            allocate(mBuffers.bondFlags,mBondBucket+1);allocate(mBuffers.bondMap,mBondBucket+1);
            allocate(mBuffers.identity,input.nodes);allocate(mBuffers.component,input.nodes);allocate(mBuffers.bondIdentity,input.bonds);
            allocate(mBuffers.begin,mNodeBucket+1);allocate(mBuffers.refs,2*mBondBucket);allocate(mBuffers.counts,2);
            allocate(mBuffers.keys,2*mBondBucket);allocate(mBuffers.sorted,2*mBondBucket);allocate(mBuffers.bonds,input.bonds);allocate(mStatus,1);
            size_t bytes=0;
            check(cub::DeviceScan::ExclusiveSum(nullptr,bytes,mBuffers.nodeFlags,mBuffers.nodeMap,mNodeBucket+1,stream));mScratchBytes=bytes;
            check(cub::DeviceScan::ExclusiveSum(nullptr,bytes,mBuffers.bondFlags,mBuffers.bondMap,mBondBucket+1,stream));mScratchBytes=std::max(mScratchBytes,bytes);
            check(cub::DeviceScan::InclusiveScan(nullptr,bytes,mBuffers.begin,mBuffers.begin,cub::Max(),mNodeBucket+1,stream));mScratchBytes=std::max(mScratchBytes,bytes);
            check(cub::DeviceRadixSort::SortKeys(nullptr,bytes,mBuffers.keys,mBuffers.sorted,2*mBondBucket,0,64,stream));mScratchBytes=std::max(mScratchBytes,bytes);
            check(cudaMalloc(&mScratch,mScratchBytes));check(cudaMemsetAsync(mStatus,0,sizeof(Status),stream));
            check(cudaMemsetAsync(mBuffers.counts,0,2*sizeof(unsigned),stream));
        } catch(...){release();throw;}
    }
    ~PackedLevel(){cudaStreamSynchronize(mStream);release();}
    PackedLevel(const PackedLevel&)=delete;PackedLevel& operator=(const PackedLevel&)=delete;
    // Called once during graph preparation. Switch branches specialize work
    // size, not physics. Rebuild execution touches at most twice the live
    // source rows/edges; unchanged generations select no branch at all.
    cudaGraphNode_t append(cudaGraph_t graph,cudaGraphNode_t prior){
        if(mAppended)throw std::runtime_error("Resident packed level already appended");
        cudaGraphConditionalHandle handles[3];for(auto& handle:handles)check(cudaGraphConditionalHandleCreate(&handle,graph,Invalid,cudaGraphCondAssignDefault));
        void* args[]={&mInput,&mParentStatus,&mStatus,&handles[0],&handles[1],&handles[2]};
        cudaKernelNodeParams kernel{};kernel.func=(void*)beginPacking;kernel.gridDim=dim3(1);kernel.blockDim=dim3(1);kernel.kernelParams=args;
        cudaGraphNode_t node;check(cudaGraphAddKernelNode(&node,graph,prior?&prior:nullptr,prior?1:0,&kernel));prior=node;
        cudaStream_t stream=nullptr;check(cudaStreamCreateWithFlags(&stream,cudaStreamNonBlocking));
        try {
            for(unsigned phase=0;phase<3;++phase){
                cudaGraphNodeParams p{};p.type=cudaGraphNodeTypeConditional;p.conditional.handle=handles[phase];
                p.conditional.type=cudaGraphCondTypeSwitch;p.conditional.size=cases(phase==1?mBondBucket:mNodeBucket);
                check(cudaGraphAddNode(&node,graph,&prior,1,&p));prior=node;
                for(unsigned index=0;index<p.conditional.size;++index)capture(p.conditional.phGraph_out[index],phase,1u<<index,stream);
            }
            check(cudaStreamDestroy(stream));mAppended=true;return prior;
        } catch(...){cudaStreamDestroy(stream);throw;}
    }
    Input view()const{
        Input next{};next.nodes=mInput.nodes;next.bonds=mInput.bonds;next.begin=mBuffers.begin;next.refs=mBuffers.refs;
        next.component=mBuffers.component;next.position=mInput.position;next.generation=mInput.generation;next.accept=mInput.accept;
        next.levelBonds=mBuffers.bonds;next.identity=mBuffers.identity;next.counts=mBuffers.counts;next.sourceStatus=mStatus;
        next.authoredNodes=mInput.authoredNodes?mInput.authoredNodes:mInput.nodes;next.bondIdentity=mBuffers.bondIdentity;return next;
    }
    PackingBuffers buffers()const{return mBuffers;}
    const Status* status()const{return mStatus;}
};
}}}
